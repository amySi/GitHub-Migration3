# maven-project

Simple Maven Project conflict

